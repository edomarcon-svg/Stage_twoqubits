Riepilogo leggero. Tutti gli array, grafici, metadati e sorgenti sono nell'archivio completo esterno.
File inclusi: summary.csv, config.json
File esclusi per dimensione: 
